import random
from game import constants
from game.actor import Actor
from game.point import Point

# TODO: Define the Food class here